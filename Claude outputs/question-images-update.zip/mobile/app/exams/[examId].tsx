import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';

import { MathText } from '@/components/MathText';
import { ResolvedImage } from '@/components/ResolvedImage';
import { useLanguage } from '@/context/LanguageContext';
import { cardShadow, colors, gradientBrand, radius, spacing } from '@/constants/theme';
import { getExamStatus, startExam, submitExam } from '@/lib/api';
import type { ExamAnswerSubmit, ExamStartResult, ExamStatus, ExamSubmitResult } from '@/lib/types';

const STRINGS = {
  ar: {
    loading: 'بيحمل...',
    intro: 'امتحان',
    passingBar: (p: number) => `محتاج تعدي بنسبة ${p}% على الأقل`,
    alreadyPassed: (score: number) => `أنت عديت الامتحان ده قبل كده — أفضل نتيجة ${Math.round(score)}%`,
    startButton: 'ابدأ الامتحان',
    resumeButton: 'كمّل الامتحان',
    retakeButton: 'أعد المحاولة',
    timerLabel: 'الوقت',
    submitButton: 'تسليم الامتحان',
    submitting: 'بيتسلم...',
    answerPlaceholder: 'اكتب إجابتك...',
    resultHeading: (correct: number, total: number) => `${correct} من ${total} صح`,
    resultPercent: (p: number) => `النتيجة: ${Math.round(p)}%`,
    resultDuration: (mmss: string) => `الوقت المستغرق: ${mmss}`,
    passMessage: 'مبروك! عديت الامتحان.',
    failMessage: 'للأسف مقدرتش تعدي — تقدر تعيد المحاولة.',
    correct: 'صح',
    incorrect: 'غلط',
    backButton: 'رجوع للفصل',
    tryAgainButton: 'إعادة المحاولة',
    loadError: 'الامتحان مش موجود أو حصلت مشكلة في التحميل.',
  },
  en: {
    loading: 'Loading...',
    intro: 'Exam',
    passingBar: (p: number) => `You need at least ${p}% to pass`,
    alreadyPassed: (score: number) => `You already passed this exam — best score ${Math.round(score)}%`,
    startButton: 'Start exam',
    resumeButton: 'Resume exam',
    retakeButton: 'Retake',
    timerLabel: 'Time',
    submitButton: 'Submit exam',
    submitting: 'Submitting...',
    answerPlaceholder: 'Type your answer...',
    resultHeading: (correct: number, total: number) => `${correct}/${total} correct`,
    resultPercent: (p: number) => `Score: ${Math.round(p)}%`,
    resultDuration: (mmss: string) => `Time taken: ${mmss}`,
    passMessage: 'Congrats! You passed.',
    failMessage: "You didn't pass this time — you can retake it.",
    correct: 'Correct',
    incorrect: 'Incorrect',
    backButton: 'Back to chapter',
    tryAgainButton: 'Try again',
    loadError: "This exam doesn't exist, or something went wrong loading it.",
  },
};

function formatDuration(totalSeconds: number): string {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export default function ExamScreen() {
  const { examId } = useLocalSearchParams<{ examId: string }>();
  const router = useRouter();
  const { language } = useLanguage();
  const t = STRINGS[language];

  const [phase, setPhase] = useState<'loading' | 'intro' | 'taking' | 'submitting' | 'result' | 'error'>('loading');
  const [status, setStatus] = useState<ExamStatus | null>(null);
  const [session, setSession] = useState<ExamStartResult | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [result, setResult] = useState<ExamSubmitResult | null>(null);
  const [nowTick, setNowTick] = useState(() => Date.now());

  const load = useCallback(() => {
    if (!examId) return;
    setPhase('loading');
    getExamStatus(examId)
      .then((s) => {
        setStatus(s);
        setPhase('intro');
      })
      .catch(() => setPhase('error'));
  }, [examId]);

  useEffect(() => {
    load();
  }, [load]);

  // Server-anchored elapsed timer — ticks every second off the wall clock,
  // but the number displayed is always `now - session.started_at` (a
  // server timestamp), never a locally-reset stopwatch. See
  // ExamStartResult.started_at's comment in lib/types.ts.
  useEffect(() => {
    if (phase !== 'taking') return;
    const interval = setInterval(() => setNowTick(Date.now()), 1000);
    return () => clearInterval(interval);
  }, [phase]);

  const onStart = async () => {
    if (!examId) return;
    setPhase('loading');
    try {
      const s = await startExam(examId);
      setSession(s);
      setAnswers({});
      setNowTick(Date.now());
      setPhase('taking');
    } catch {
      setPhase('error');
    }
  };

  const allAnswered = session ? session.questions.every((q) => (answers[q.id] ?? '').trim().length > 0) : false;

  const onSubmit = async () => {
    if (!session || !allAnswered) return;
    setPhase('submitting');
    try {
      const payload: ExamAnswerSubmit[] = session.questions.map((q) => ({
        question_id: q.id,
        submitted_answer: answers[q.id],
      }));
      const r = await submitExam(session.attempt_id, payload);
      setResult(r);
      setPhase('result');
    } catch {
      setPhase('error');
    }
  };

  if (phase === 'loading') {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator color={colors.primary} size="large" />
        <Text style={styles.loadingText}>{t.loading}</Text>
      </View>
    );
  }

  if (phase === 'error') {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.errorText}>{t.loadError}</Text>
      </View>
    );
  }

  if (phase === 'intro' && status) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.introTitle}>{t.intro}</Text>
        {status.passed ? (
          <Text style={styles.introPassed}>{t.alreadyPassed(status.best_score_percent ?? 0)}</Text>
        ) : null}
        <Pressable style={styles.startWrap} onPress={onStart}>
          <LinearGradient colors={gradientBrand} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.startButton}>
            <Text style={styles.startButtonText}>
              {status.in_progress_attempt_id ? t.resumeButton : status.passed ? t.retakeButton : t.startButton}
            </Text>
          </LinearGradient>
        </Pressable>
      </View>
    );
  }

  if (phase === 'taking' && session) {
    const elapsedSeconds = Math.max(0, Math.floor((nowTick - new Date(session.started_at).getTime()) / 1000));
    return (
      <View style={styles.container}>
        <View style={styles.timerBar}>
          <Text style={styles.timerText}>
            ⏱ {t.timerLabel}: {formatDuration(elapsedSeconds)}
          </Text>
        </View>
        <ScrollView contentContainerStyle={styles.scrollContent}>
          {session.questions.map((q, index) => (
            <View key={q.id} style={styles.card}>
              <Text style={styles.questionIndex}>{index + 1}.</Text>
              {q.image_url ? (
                <ResolvedImage
                  url={q.image_url}
                  style={styles.questionImage}
                  containerStyle={styles.questionImage}
                />
              ) : null}
              <MathText text={q.prompt} color={colors.text} fontSize={15} />

              {q.question_type === 'multiple_choice' && q.choices ? (
                <View style={styles.choices}>
                  {Object.entries(q.choices).map(([key, label]) => {
                    const selected = answers[q.id] === key;
                    return (
                      <Pressable
                        key={key}
                        style={[styles.choiceRow, selected && styles.choiceRowSelected]}
                        onPress={() => setAnswers((prev) => ({ ...prev, [q.id]: key }))}
                      >
                        <Text style={[styles.choiceText, selected && styles.choiceTextSelected]}>{label}</Text>
                      </Pressable>
                    );
                  })}
                </View>
              ) : (
                <TextInput
                  style={styles.textInput}
                  placeholder={t.answerPlaceholder}
                  placeholderTextColor={colors.textFaint}
                  value={answers[q.id] ?? ''}
                  onChangeText={(v) => setAnswers((prev) => ({ ...prev, [q.id]: v }))}
                />
              )}
            </View>
          ))}

          <Pressable
            style={[styles.submitWrap, !allAnswered && styles.submitWrapDisabled]}
            onPress={onSubmit}
            disabled={!allAnswered}
          >
            <LinearGradient
              colors={gradientBrand}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.submitButton}
            >
              <Text style={styles.submitButtonText}>{t.submitButton}</Text>
            </LinearGradient>
          </Pressable>
        </ScrollView>
      </View>
    );
  }

  if (phase === 'submitting') {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator color={colors.primary} size="large" />
        <Text style={styles.loadingText}>{t.submitting}</Text>
      </View>
    );
  }

  if (phase === 'result' && result) {
    return (
      <View style={styles.container}>
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.summary}>
            <Text style={[styles.summaryHeading, result.passed ? styles.summaryGood : styles.summaryBad]}>
              {t.resultHeading(result.correct_count, result.total_count)}
            </Text>
            <Text style={styles.summarySub}>{t.resultPercent(result.score_percent)}</Text>
            <Text style={styles.summarySub}>{t.resultDuration(formatDuration(result.duration_seconds))}</Text>
            <Text style={styles.summaryMessage}>{result.passed ? t.passMessage : t.failMessage}</Text>
          </View>

          {result.answers.map((a, index) => (
            <View key={a.question_id} style={styles.card}>
              <Text style={styles.questionIndex}>{index + 1}.</Text>
              <View style={styles.resultRow}>
                <Text
                  style={[styles.resultBadge, a.is_correct ? styles.resultBadgeGood : styles.resultBadgeBad]}
                >
                  {a.is_correct ? `✓ ${t.correct}` : `✕ ${t.incorrect}`}
                </Text>
                {a.explanation ? <Text style={styles.explanation}>{a.explanation}</Text> : null}
              </View>
            </View>
          ))}

          <View style={styles.resultActions}>
            {!result.passed ? (
              <Pressable style={styles.retakeWrap} onPress={onStart}>
                <Text style={styles.retakeText}>{t.tryAgainButton}</Text>
              </Pressable>
            ) : null}
            <Pressable style={styles.backWrap} onPress={() => router.back()}>
              <LinearGradient
                colors={gradientBrand}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.backButton}
              >
                <Text style={styles.backButtonText}>{t.backButton}</Text>
              </LinearGradient>
            </Pressable>
          </View>
        </ScrollView>
      </View>
    );
  }

  return null;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  centerContainer: {
    flex: 1,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },
  loadingText: { color: colors.textMuted, marginTop: spacing.md },
  errorText: { color: colors.danger, textAlign: 'center' },

  introTitle: { fontSize: 22, fontWeight: '700', color: colors.text, marginBottom: spacing.md },
  introPassed: { color: colors.success, fontWeight: '600', marginBottom: spacing.lg, textAlign: 'center' },
  startWrap: { marginTop: spacing.md, width: '100%', maxWidth: 320 },
  startButton: { borderRadius: radius.pill, paddingVertical: 16, alignItems: 'center' },
  startButtonText: { color: colors.onPrimary, fontWeight: '700', fontSize: 16 },

  timerBar: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.xl,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    alignItems: 'center',
  },
  timerText: { color: colors.primary, fontWeight: '700', fontSize: 14 },

  scrollContent: { padding: spacing.xl, paddingBottom: spacing.xxl * 2 },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  questionIndex: { color: colors.textFaint, fontSize: 12, fontWeight: '700', marginBottom: 2 },
  questionImage: {
    width: '100%',
    height: 180,
    borderRadius: radius.md,
    marginBottom: spacing.sm,
    backgroundColor: colors.surfaceAlt,
  },
  choices: { marginTop: spacing.sm, gap: spacing.sm },
  choiceRow: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: spacing.md,
    backgroundColor: colors.surfaceAlt,
  },
  choiceRowSelected: { borderColor: colors.primary },
  choiceText: { color: colors.text, fontSize: 14 },
  choiceTextSelected: { color: colors.primary, fontWeight: '600' },
  textInput: {
    marginTop: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: spacing.md,
    color: colors.text,
    backgroundColor: colors.surfaceAlt,
  },

  submitWrap: { marginTop: spacing.sm },
  submitWrapDisabled: { opacity: 0.5 },
  submitButton: { borderRadius: radius.pill, paddingVertical: 14, alignItems: 'center' },
  submitButtonText: { color: colors.onPrimary, fontWeight: '700', fontSize: 16 },

  resultRow: { marginTop: spacing.sm },
  resultBadge: { fontSize: 13, fontWeight: '700', marginBottom: 4 },
  resultBadgeGood: { color: colors.success },
  resultBadgeBad: { color: colors.danger },
  explanation: { color: colors.textMuted, fontSize: 13, lineHeight: 19 },

  summary: {
    alignItems: 'center',
    marginBottom: spacing.lg,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    ...cardShadow,
  },
  summaryHeading: { fontSize: 22, fontWeight: '700', marginBottom: spacing.xs },
  summaryGood: { color: colors.success },
  summaryBad: { color: colors.danger },
  summarySub: { color: colors.textMuted, fontSize: 13, marginTop: 2 },
  summaryMessage: { color: colors.text, textAlign: 'center', marginTop: spacing.sm, fontWeight: '600' },

  resultActions: { marginTop: spacing.md, gap: spacing.sm },
  retakeWrap: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.pill,
    paddingVertical: 14,
    alignItems: 'center',
  },
  retakeText: { color: colors.textMuted, fontWeight: '600' },
  backWrap: {},
  backButton: { borderRadius: radius.pill, paddingVertical: 14, alignItems: 'center' },
  backButtonText: { color: colors.onPrimary, fontWeight: '700', fontSize: 16 },
});
